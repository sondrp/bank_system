# Scala Project I



### Usage

Navigate to project root folder, and run command: `sbt run`.
